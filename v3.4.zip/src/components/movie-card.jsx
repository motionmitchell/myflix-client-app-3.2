import React from "react";


class MovieCard extends React.Component {
    constructor(props) {
        super(props);
		//console.log (props);
        this.state = {
            
        }
    }
    showMovie = (id)=>{
        
		this.props.setMovieView(id);
    }
    render() {
        return (<div><ol>
            {this.props.movies.map ((movie, idx)=>(
                <li><button onClick={()=>this.showMovie(idx)}>{movie.description}</button></li>
            ))}
            </ol>
        </div>);
    }

}
export default MovieCard;