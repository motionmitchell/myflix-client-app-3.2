import React from "react";
import { Link } from "react-router-dom";
import { Container, Row, Col } from 'react-bootstrap';
import { connect } from 'react-redux';
import { getMovieList, addToFavorites } from '../reducer';
import VisibilityFilterInput from "./VisibilityFilterInput";
import 'bootstrap/dist/css/bootstrap.css';
class MovieCard extends React.Component {
    constructor(props) {
        super(props);

        //  this.SERVER_ROOT_URL = "https://ryanm-movies.herokuapp.com/";

        this.state = {
            movies: this.props.movies,
            filteredMovies: [],
            movie: null,
            isLoaded: false,
            error: null,
            visibilityFilter: ""
        }
        console.log("loaded");

    }
    componentDidMount() {
        this.props.getMovieList().then((data) => {
            console.log("done", data);
            this.setState({ movies: data.payload.movies, filteredMovies: data.payload.movies, isLoaded: true });
        })
        // this.setState({ movies: this.props.movies, isLoaded: true });
    }

    setFilter = (val) => {
        // alert(val);
        const value = (val + "").toLowerCase();
        this.setState({ filteredMovies: this.state.movies.filter(m => m.description.toLowerCase().indexOf(value) > -1) });
    }
    addToFavorites = (id) => {
        //alert(id);
        this.props.addToFavorites({ id: id }).then((result) => {
            console.log(result);
            alert(result.payload.msg.message);
        });
    }
    loadData = () => {
        //alert("loadData");
    }
    render() {
        if (!this.state.isLoaded) {
            return (<div>loading...</div>);
        }
        return (
            <div>
                <VisibilityFilterInput setFilter2={this.setFilter} visibilityFilter={this.visibilityFilter} />
                <Container>
                    <Row className="show-grid" key="id">
                        <Col><h4>Title</h4>
                        </Col>
                        <Col>
                            <h4>Director Name</h4>
                        </Col>
                        <Col>
                            <h4>Genre</h4>
                        </Col>
                        <Col>
                            <h4>Add to Favorites</h4>
                        </Col>
                    </Row>
                    {this.state.filteredMovies.map((movie, idx) => (
                        <Row className="show-grid" key="id">
                            <Col className='btn-light'><Link to={`/movies/${movie.id}`}>{movie.description}</Link>
                            </Col>
                            <Col className='btn-light'>
                                {movie.director.name}
                            </Col>
                            <Col className='btn-light'>
                                {movie.genre.category}
                            </Col>
                            <Col className='btn-light'>
                                <button onClick={() => this.addToFavorites(movie.id)}><img width='10%' height='10%' src='favorites.jpg' /></button>
                            </Col>
                        </Row>
                    ))}
                </Container>
            </div>);
    }
}

const mapStateToProps = (state) => {
    console.log("mapStateToProps.movies:", state.movies);
    return {
        movies: state.movies
    }
}
const mapDispatchToProps = (dispatch, ownProps) => {
    const getMovies = () => dispatch(getMovieList());
    return {
        getMovieList: getMovies,
        addToFavorites: id => dispatch(addToFavorites(id)),
    }

    // console.log("mapDispatchToProps",getMovies);

}

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(MovieCard)
